# WSD_Lab13
MySQL Connection in NodeJS

API route working as expected:
![image](https://github.com/aaravdubey/WSD_Lab13/assets/69917219/966ba696-1e75-40f6-9489-29e1770c5fc7)

Data in reservations & rooms tables:
![image](https://github.com/aaravdubey/WSD_Lab13/assets/69917219/a6324747-40d4-45d5-9811-bd90988b2667)
![image](https://github.com/aaravdubey/WSD_Lab13/assets/69917219/44fc07af-8ac4-4594-aa31-22163c70fe02)

